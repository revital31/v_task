const mysql = require('mysql');


const pool = mysql.createPool({
host:'localhost',
user:'ofir2',
password:'1234',
database:'vacation_destinations'
//insecureAuth : true
});


   
pool.on('acquire',(db)=>{
    console.log(`Acquire connection id:${db.threadId}`)
    });
    

    pool.on('enqueue',()=>{
        console.log('waiting for available connection slot');
    });

    
   
   pool.on('release', (db) => {
    console.log('Connection ${db.threadId} released');
  });


 
  module.exports = {pool}
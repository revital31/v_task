const express = require("express");
const app = express();
const {pool} = require('..../../../../pool/dbconnection');
const cors = require("cors");

app.use(
  cors({
    mode: "no-cors",
    origin: "http://localhost:3000",
  })
);

//all info from vactions chart= databasde- mysql
app.route("/vacations").get((req, res) => {
  pool.query("SELECT * FROM vacation_destinations.vacations;", (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

//all info from users chart= databasde- mysql
app.route("/users").get((req, res) => {
  pool.query("SELECT * FROM vacation_destinations.users;", (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});


//all info from adminstrator chart= databasde- mysql
app.route("/administrator").get((req, res) => {
  pool.query("SELECT * FROM vacation_destinations.administrator;", (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});





const port = process.env.PORT || 8000;
app.listen(port, () => console.log(`server started on port ${port}`));

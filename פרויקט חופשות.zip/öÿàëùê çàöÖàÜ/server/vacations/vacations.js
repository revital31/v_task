const express = require("express");
const path = require("path");
const { pool } = require("../../pool/dbconnection");
const passport= require('passport');
const LocalStrategy=require('passport-local').Strategy;
const app = express();
const cors = require("cors");



app.use(
  cors({
    mode: "no-cors",
    origin: "http://localhost:3000",
  })
);


const user = {
  firstname:'revital',
  lastname:'bl',
  username: 'revital1',
  password: '123'
  //admin:true
}





// הכנסת ה stratergy לתוך הpassport

//passport autentication with local strategy
    
passport.use(new LocalStrategy((username,password, done ) =>{
  try {

          //check if user exist
  //פה בדרך כלל פונים לdatabase
  if(username === user.username && password === user.password ) {
      return done(null,user);
  }
  // user doesn't exist
  return done (null,false);



  } catch(e) {
      //error
      done(e);
  }
  

}));


//החלטה מה ישמר בסשן
passport.serializeUser((user,done)=>{
    const {username} = user;
    done(null,{username});
});

//קבלת המידע מהסשן
passport.deserializeUser((user,done)=>{
    done(null,user);
});


const isAuthorized =(req,res,next) =>{
  if (req.isAuthenticated() && req.user.username && req.user.password) return next();
  res.redirect('registration')
  }
  
  // middleware שאמורים לפרסר גייסון ואת הטופס
  app.use(express.urlencoded({extended:false}));
  app.use(express.json());
  
  
  
//חיבור אקספרס לפספורט
app.use(passport.initialize());
app.use(passport.session());






//כדי שה סטייל יעבודmaybe delete מיותר
app.use(express.static(path.join(__dirname, "public")));

app.route("/vacations1").get((req, res) => {
  res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vacations.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
 
    
</head>
<body style="background-Color:yellowgreen;">
<h1 style ="color:green; text-align:center;font-size:60px;" > Vacations</h1>



<div style = "display:grid; grid-template-columns:repeat(3,0.3fr);grid-gap:10px;padding:20px;margin:60px;height:30px; id="card1">
<div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
<div class="card-header">Header</div>
  <div class="card-body">
    <h5 class="card-title">Primary card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
</div>

<div id="card2">
<div class="card text-white bg-success mb-3" style="max-width: 18rem;">
  <div class="card-header">Header</div>
  <div class="card-body">
    <h5 class="card-title">Success card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
</div>
</div>

<div id="card3">
<div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
  <div class="card-header">Header</div>
  <div class="card-body">
    <h5 class="card-title">Danger card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
</div>
</div>

<div id="card4">
<div class="card text-white bg-warning mb-3" style="max-width: 18rem;">
  <div class="card-header">Header</div>
  <div class="card-body">
    <h5 class="card-title">Warning card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
</div>
</div>

<div id="card5">
<div class="card text-white bg-info mb-3" style="max-width: 18rem;">
  <div class="card-header">Header</div>
  <div class="card-body">
    <h5 class="card-title">Info card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
</div>
</div>

<div id="card6">
<div class="card bg-light mb-3" style="max-width: 18rem;">
  <div class="card-header">Header</div>
  <div class="card-body">
    <h5 class="card-title">Light card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
</div>

</div>

</div>

</body>
</html>

`);
})

//אוטנטיקציה
.post(passport.authenticate('local',{
  failureRedirect:'/registration',
  successRedirect:'/vacations1'
}));


app.route("/registration",isAuthorized, ).get((req, res) => {
  res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vacations.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
 
    
</head>
<body style="background-Color:yellowgreen;">
<h1 style= "color:green; text-align:center;font-size:60px;" > Vacations</h1>
<h1>Sign In</h1>
<form method = "POST" action= "/vacations1">
<input type ="text" name="firstname" placeholder ="Enter your first name">
<input type ="text" name="lastname" placeholder ="Enter your last name">
<input type ="text" name="username" placeholder ="Enter your user name">
<input type ="text" name="password" placeholder ="Enter your password">
<input type="submit" value="submit" class="btn btn-danger btn-sm"></button>

</form>



</body>
</html>

`);
})





const PORT = process.env.PORT || 4000;

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));

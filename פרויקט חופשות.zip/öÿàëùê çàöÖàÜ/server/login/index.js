const express = require('express');
const path =require('path');
const { pool } = require("../../pool/dbconnection");
const passport= require('passport');
const session= require('express-session');
const LocalStrategy=require('passport-local').Strategy;
const app = express();
const cors = require("cors");

app.use(
    cors({
      mode: "no-cors",
      origin: "http://localhost:3000",
    })
  );


const user = {
    username: 'revital',
    password: '123',
    admin:true
}





// הכנסת ה stratergy לתוך הpassport

//passport autentication with local strategy
    
passport.use(new LocalStrategy((username,password, done ) =>{
    try {

            //check if user exist
    //פה בדרך כלל פונים לdatabase
    if(username === user.username && password === user.password ) {
        return done(null,user);
    }
    // user doesn't exist
    return done (null,false);



    } catch(e) {
        //error
        done(e);
    }
    

}));

//החלטה מה ישמר בסשן
passport.serializeUser((user,done)=>{
    const {username,admin} = user;
    done(null,{username,admin});
});

//קבלת המידע מהסשן
passport.deserializeUser((user,done)=>{
    done(null,user);
});

const isAuthorized =(req,res,next) =>{
if (req.isAuthenticated() && req.user && req.user.admin) return next();
res.redirect('/login')
}

// middleware שאמורים לפרסר גייסון ואת הטופס
app.use(express.urlencoded({extended:false}));
app.use(express.json());



//הגדרת סשן
app.use(session({
name:'sessionID',
secret:process.env.SECRET||'reuyukfgdd76568999064',
resave:false,
saveUninitialized:true,
cookie: {
    maxAge:1200*1200*7000,
    httpOnly:true,
    //response:setHeader("Set-Cookie", "HttpOnly;Secure;SameSite=Strict")
}
}));









//חיבור אקספרס לפספורט
app.use(passport.initialize());
app.use(passport.session());





app.use(express.static (path.join(__dirname,'public')));
app.route('/login')
. get ((req,res) => {
res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
<body style="background-Color:lightblue;">
<h1 style="color:green; text-align:center;font-size:60px;">Sign In</h1>
<div style="margin:20px;" "padding:30px;" id="form">
<form method = "POST" action= "/login">
<value>user name:</value>
<input style="padding:10px;" type ="text" name="username" placeholder ="Enter your user name">
<value> password:</value>
<input style="padding:10px;" type ="text" name="password" placeholder ="Enter your password">
<input  type="submit" value="submit" class="btn btn-danger btn-sm"></button>
</form>
</div>

 <script>

 </script>   
</body>
</html>

`);
})

//אוטנטיקציה
.post(passport.authenticate('local',{
    failureRedirect:'/login',
    successRedirect:'/registration'
}));

//לבדוק אוליי מיותר כי הדף לא קיים לבדוק 
app.get ('/logout',isAuthorized,(req,res)=>{
    req.logout();
    res.redirect('/login');
});


app.use(express.static (path.join(__dirname,'public')));
app.get('/registration',isAuthorized, (req,res) => {
    
    res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
<body style="background-Color:green">

 <h1 style ="color:green; text-align:center;font-size:60px;">Registration</h1>
 <h2 style ="color:blue; text-align:center;font-size:60px;">Please Fill The Registration Form</h2>


<script>
window.location.href = "http://localhost:4000/registration";
   

</script>

</body>
</html>

`);
});



 

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
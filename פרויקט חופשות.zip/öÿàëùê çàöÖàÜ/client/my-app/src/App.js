import React from "react";
import "./App.css";
import Nav from './components/Nav/Nav';
import MainAdmin from "./components/MainAdmin/MainAdmin";
import Home from './components/Home/Home';
import AddVacation from './components/AddVacationComponent/AddVacation';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

function App() {
  return (
    <Router>
      <div className="App">
      <Nav />
                   
        <Switch>
        <Route path= "/home" exact component={Home} />
          <Route path="/MainAdmin" component={MainAdmin} />
          <Route path="/AddVacation" component={AddVacation} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;

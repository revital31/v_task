import React from 'react';
import './Nav.css';
import {Link} from 'react-router-dom';

function Nav() {

    const navStyle = {
        color: 'red'
        
    }; 

  return (
    <nav>
        
        <ul className ="nav-links">
        <Link style={navStyle} to ='/Home'>
             <li>Home Page</li>
            </Link>
            <Link style={navStyle} to ='/MainAdmin'>
             <li>Admin Page</li>
            </Link>
            <Link style={navStyle} to ='/AddVacation'>
             <li>Add Vacation</li>
            </Link>
                    

            
        </ul>
    </nav>
      
  );
}

export default Nav;

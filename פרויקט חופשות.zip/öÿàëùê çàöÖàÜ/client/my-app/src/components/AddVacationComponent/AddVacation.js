import React, { Component } from "react";
import './AddVacation.css';


class AddVacation extends Component {
    
  constructor() {
    super();
    this.state = {
      vacations: [],
    };
  }


  
  componentDidMount() {
    fetch("http://localhost:8000/vacations")
      .then((res) => res.json())
      .then((vacations) =>
        this.setState({ vacations }, () =>
          console.log("vactions info fetched..", vacations)
        )
      );
  }

  render() {
      
  function handleAdd() {
    alert('vaction added')
    
  }
    return (
      <div>
        <h1> Where Would You Like to Go </h1>
        <form>
        <value>description:</value>
        <input type ="text" name="description" placeholder ="Describe.."/> 
        <value>price:</value>
        <input type ="text" name="price" placeholder ="price.."/>
         <label for="myfile">Select a file:</label>
        <input type="file" id="myfile" name="myfile"></input>
        <value>Deparature_Date:</value>
        <input type ="date" name="Deparature_Date" placeholder ="Deparature_Date"/> 
        <value>Return_Date:</value>
        <input type ="date" name="Return_Date" placeholder ="Return_Date"/> 
         
        </form>
        <button style={{color:'red',fontSize:'20px'}} onClick={handleAdd}>Add A Vacation</button>
        <hr></hr>
        <ul>
          {this.state.vacations.map((vacation) => (
              <li key={vacation.id}>
              {" "}
          {vacation.vacation_Description} 
          <li>
              
          {vacation.Price} 
          </li>
          <li>
              {vacation.Deparature_Date} 
          </li>
          <li>
              {vacation.return_Date}{" "}
          </li>
           
            </li>
          ))}
        </ul>
      </div>
      
    );
  }
}

export default AddVacation;

const mysql = require('mysql');

const db = mysql.createConnection({
host:'localhost',
user:'ofir2',
password:'1234',
database:'vacation_destinations'
//insecureAuth : true
});




//קבלת מידע-נותן את כל המידע
//get info from users

db.query('SELECT * FROM users',(err,res,fields)=>{
    if (err) throw err;
    console.log(res);
    console.log(fields);
    });
    

    // get al info from adminstrator

    db.query('SELECT * FROM administrator',(err,res,fields)=>{
        if (err) throw err;
        console.log(res);
        console.log(fields);
        });
        